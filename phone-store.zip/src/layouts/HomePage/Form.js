import React from 'react'

export default function Form() {
    return (
        <div>
            <h1>form</h1>
            <h1>form</h1>
            <h1>form</h1>
            <h1>form</h1>
            <h1>form</h1>
            <h1>form</h1>
            <h1>form</h1>
            <h1>form</h1>
        </div>
    )
}
