import phone from '../assets/images/phone.png';
import dongho from '../assets/images/dongho.png';
import laptop from '../assets/images/laptop.png';
import pc from '../assets/images/pc.png';
import phukien from '../assets/images/phukien.png';
import smat from '../assets/images/smat.png';
import tablet from '../assets/images/tablet.png';
import logo from '../assets/images/logo.png';
import emty from '../assets/images/emty.jpg'

const Images = { phone, dongho, pc, phukien, smat, tablet, laptop, logo, emty }


export default Images

